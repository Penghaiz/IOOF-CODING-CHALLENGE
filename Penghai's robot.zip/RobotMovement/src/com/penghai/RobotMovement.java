package com.penghai;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import net.sf.json.JSONObject;

/**
 * @author Penghai Zhang  -  23//11/2017
 */
@WebServlet(description = "this servlet validates commands given by user and returns results in JSON format to user", urlPatterns = {
		"/RobotMovement" })
public class RobotMovement extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private static int currentCoordinateX; // store the robot's current coordinate X
	private static int currentCoordinateY; // store the robot's current coordinate y
	private static String currentOrientation; // store the robot's current orientation
	private static String info; // store more information about the execution of each command

	/**
	 * This function invokes different specific functions based on commands received from GET requests.
	 * 'response.getWriter().println' is used to return results. 
	 * The type of results is JSON.
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String command = request.getParameter("command").isEmpty()? " " : request.getParameter("command");
			switch (command) {
			case "place":
				int coordinateX = Integer.parseInt(request.getParameter("coordinateX"));
				int coordinateY = Integer.parseInt(request.getParameter("coordinateY"));
				String orientation = request.getParameter("orientation");
				placeRobot(coordinateX, coordinateY, orientation);
				break;
			case "move":
				moveRobot();
				break;
			case "left":
				turnRobot("left");
				break;
			case "right":
				turnRobot("right");
				break;
			case "report":
				break;
			default:
				break;
			}
		response.getWriter().println(returnResult(command));
	}

	/**
	 * This function places the robot in different positions of the table, 
	 * and sets which orientation the robot is facing,
	 * @param coordinateX : the robot's new coordinate X 
	 * @param coordinateY : the robot's new coordinate Y 
	 * @param orientation : the robot's new orientation
	 * 
	 */
	private void placeRobot(int coordinateX, int coordinateY, String orientation) {
		currentCoordinateX = coordinateX;
		currentCoordinateY = coordinateY;
		currentOrientation = orientation;
		info = "success";
	}

	/**
	 * This function moves the robot forward by one unit based on the direction it is currently facing. 
	 * Before moving the robot, function coordinateValidating is called to check whether the robot can move or not.
	 */
	private void moveRobot() {
		if (coordinateValidating()) {
			switch (currentOrientation) {
			case "east":
				currentCoordinateX = currentCoordinateX + 1;
				break;
			case "west":
				currentCoordinateX = currentCoordinateX - 1;
				break;
			case "north":
				currentCoordinateY = currentCoordinateY + 1;
				break;
			case "south":
				currentCoordinateY = currentCoordinateY - 1;
				break;
			default:
				break;
			}
			info = "success";
		} else {
			info = "failed";
		}
	}

	/**
	 *  Because the dimension of the table is 5 * 5, so both coordinate X and Y range from 0 to 4.
	 *  There are four conditions that the robot will fall from the table if it keep moving forward.
	 *  The first one is when the robot is east facing and its current coordinate X is 4. 
	 *  This means the robot is standing at the table's right edge, and the next forward movement results in its falling from the table.
	 *  Likewise, that current coordinate X is 0 means the robots has reached the table's left edge
	 *  and it can't move west any more. 
	 *     
	 * @return true : the robot can move forward; false : the robot will fall from the table
	 */
	private boolean coordinateValidating() {
		if ((currentCoordinateX == 4 && currentOrientation.equals("east"))
				|| (currentCoordinateX == 0 && currentOrientation.equals("west"))
				|| (currentCoordinateY == 4 && currentOrientation.equals("north"))
				|| (currentCoordinateY == 0 && currentOrientation.equals("south"))) {

			return false;
		} else {
			return true;
		}
	}

	/**
	 * modify the robot's orientation based on its current orientation and commands
	 * @param direction : whether the robot turn left or right
	 */
	private void turnRobot(String direction) {
		switch (currentOrientation) {
		case "east":
			currentOrientation = (direction == "left" ? "north" : "south");
			break;
		case "west":
			currentOrientation = (direction == "left" ? "south" : "north");
			break;
		case "north":
			currentOrientation = (direction == "left" ? "west" : "east");
			break;
		case "south":
			currentOrientation = (direction == "left" ? "east" : "west");
			break;
		default:
			break;
		}
		info = "success";

	}

	/**
	 * @param command : the command sent from user
	 * @return A JSON object that includes the robot's coordinates and orientation and user's command and extra information.
	 */
	private JSONObject returnResult(String command) {
		Map<String, Object> results = new HashMap<String, Object>();
		results.put("coordinateX", currentCoordinateX);
		results.put("coordinateY", currentCoordinateY);
		results.put("orientation", currentOrientation);
		results.put("info", info);
		results.put("command", command);
		JSONObject resultsJSON = JSONObject.fromObject(results);
		return resultsJSON;
	}


	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public RobotMovement() {
		super();
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
}
