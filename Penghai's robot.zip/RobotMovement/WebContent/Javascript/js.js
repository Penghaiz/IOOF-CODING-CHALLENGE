/*
 * @author Penghai Zhang  23-11-2017 
 * This is the main Javascript file that contains all needed functions and variables in front-end.
 */

var isPlaced = false; //  check if the robot has been placed
var output; // load all output texts

/*
 * This function issues the command PLACE.
 * The parameter sent to sendRequest is a JSON object including the selected coordinate X and Y and  orientation and the name of command issued
 * This function also sets the value of isPlaced as true.
 */
function place() {
	sendRequest({
		coordinateX : $('#coordinateX').val(),
		coordinateY : $('#coordinateY').val(),
		orientation : $('#orientation').val(),
		command : 'place'
	});
	isPlaced = true;
}

/*
 * This function firstly checks whether the robot has been placed.  
 * If yes, it issues the command MOVE by invoking sendRequest with a parameter - a JSON object including the name of command issued.
 * If no, it gives a prompt.
 */
function move() {
	if (isPlaced) {
		sendRequest({
			command : 'move'
		});
	} else {
		alert("Sorry, I can't move before I am placed.");
	}
}

/*
 * This function firstly checks whether the robot has been placed.  
 * If yes, it issues the command LEFT by invoking sendRequest with a parameter - a JSON object including the name of command issued.
 * If no, it gives a prompt.
 */
function left() {
	if (isPlaced) {
		sendRequest({
			command : 'left'
		});
	} else {
		alert("Sorry, I can't turn left before I am placed.");
	}
}

/*
 * This function firstly checks whether the robot has been placed.  
 * If yes, it issues the command RIGHT by invoking sendRequest with a parameter - a JSON object including the name of command issued.
 * If no, it gives a prompt.
 */
function right() {
	if (isPlaced) {
		sendRequest({
			command : 'right'
		});
	} else {
		alert("Sorry, I can't turn right before I am placed.");
	}
}

/*
 * This function firstly checks whether the robot has been placed.  
 * If yes, it issues the command REPORT by invoking sendRequest with a parameter - a JSON object including the name of command issued.
 * If no, it gives a prompt.
 */
function report() {
	if (isPlaced) {
		sendRequest({
			command : 'report'
		});
	} else {
		alert("Sorry, I can't give a report before I am placed.");
	}
}

/*
 * This function uses ajax to send different commands to back-end and receive each command's result from back-end.
 * The callback parses back-end's responses to a JSON object and invokes resultHandle with this JSON object as parameter
 */
function sendRequest(data) {
	$.ajax({
		url : 'RobotMovement',
		type : 'GET',
		data : data,
		success : function(msg) {
			resultHandle($.parseJSON(msg));
		}
	})
}

/*
 * Based on the parameter passed, which is a JSON object, this function creates and display different text outputs,
 * and it invokes displayRobot to display the robot.
 * 
 * Each JSON object passed has five key/value pairs:
 * coordinateY : the robot's new coordinate Y
 * coordinateX : the robot's new coordinate X
 * orientation : the robot's new orientation
 * command : the command issued
 * info : extra information about the execution of this command
 * 
 * for example,  (coordinateY":2,"coordinateX":1, "orientation":"east","command":"error","info":"success")
 */
function resultHandle(result) {
	switch (result.command) {
	case 'place':
		if (result.info == 'success') {
			output = 'I am placed at (' + result.coordinateX + ','
					+ result.coordinateY + ') and facing ' + result.orientation
					+ '\n';
			displayRobot(result.coordinateX, result.coordinateY)

		} else {
			output = 'I can\'t be placed due to unknown reasons...' + '\n';
		}
		break;
	case 'move':
		if (result.info == 'success') {
			output = 'I  move to (' + result.coordinateX + ','
					+ result.coordinateY + ') and face ' + result.orientation
					+ '\n';
			displayRobot(result.coordinateX, result.coordinateY);
		} else {
			output = 'I can\'t  move forward '+result.orientation+' because I don\'t want to fall from the table '
					+ '\n';
		}
		break;
	case 'left':
		if (result.info == 'success') {
			output = 'I turn to ' + result.orientation + ' facing \n';
		} else {
			output = 'I can\'t turn left due to unknown reasons...' + '\n';
		}
		break;
	case 'right':
		if (result.info == 'success') {
			output = 'I turn to ' + result.orientation + ' facing \n';
		} else {
			output = 'I can\'t turn right due to unknown reasons...' + '\n';
		}
		break;
	case 'report':
		output = 'I am standing at (' + result.coordinateX + ','
				+ result.coordinateY + ') and facing ' + result.orientation
				+ '\n';
		break;
	default:
		output = 'I am sorry I can\'t recognise this command';
	}
	$('#resultsText').append(output);
}

/*
 * This functions displays the robot based on two passed parameters, which represent the robot's new coordinate X and Y.
 */
function displayRobot(coordinateX, coordinateY) {
	$("#robot").remove();
	$("#tr" + coordinateY + "_td" + coordinateX).append(
			"<img class='robot' id='robot' src='images/android_robot.png'>");
}