Front-end techniques used in this web project include: HTML, CSS, Javascript, JQuery, Bootstrap.

Back-end application is developed via Java (JDK 1.8).

The web page (index.html) can be viewed from a variety of devices.

Developing IDE : Eclipse + WebStorm

Testing environment : TOMCAT 8.0 + Chrome + WINDOWS 7